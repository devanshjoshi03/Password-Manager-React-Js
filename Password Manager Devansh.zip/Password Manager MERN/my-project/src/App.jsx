import Footer from "./Components/Footer"
import Manager from "./Components/Manager"
import Navbar from "./Components/Navbar"

function App() {

  return (
    <>
      <Navbar />
      <div className="min-h-[84vh]">

        <Manager />
      </div>
      <div >

      <Footer />
      </div>
    </>
  )
}

export default App
