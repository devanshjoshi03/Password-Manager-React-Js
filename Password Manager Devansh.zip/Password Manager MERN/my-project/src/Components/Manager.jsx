import { useEffect, useRef, useState } from "react";
import { Bounce, ToastContainer, toast } from 'react-toastify';
import { v4 as uuidv4 } from 'uuid';
import "/cross.png";
import "/images.png";
const MAnager = () => {
    const [passwordarray, setpasswordarray] = useState([]);
    const [form, setform] = useState({ site: "", username: "", password: "" });
    const re = useRef();
    const password = useRef();


    const copyText = (Text) => {
        toast('Copied To Clipboard!', {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: false,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",
            transition: Bounce,
        });
        // alert('copied ' + Text)
        navigator.clipboard.writeText(Text);
    }


    useEffect(() => {
        let passwordS = localStorage.getItem("password");
        if (passwordS) {
            setpasswordarray(JSON.parse(passwordS));
        }
    }, [])
    const showpass = () => {
        password.current.type = "text";
        if (re.current.src.includes("/cross.png")) {
            re.current.src = "/images.png"
            password.current.type = "password";

        } else {
            password.current.type = "text";
            re.current.src = "/cross.png"

        }
        // alert("show the password")

    }
    const savepass = () => {
        setpasswordarray([...passwordarray, { ...form, id: uuidv4() }]);
        localStorage.setItem("password", JSON.stringify([...passwordarray, { ...form, id: uuidv4() }]))
        toast('Information Saved !', {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: false,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",
            transition: Bounce,
        });
    }
    const deletepass = (id) => {
        let c = confirm("Do You Want To Delete");
        if(c){

            console.log('deleting password with id' + id);
            setpasswordarray(passwordarray.filter(item=>item.id!==id))
            localStorage.setItem("password", JSON.stringify(passwordarray.filter(item=>item.id!==id)))
            toast('Information Deleted !', {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: false,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",
            transition: Bounce,
        });

        }
        
        
    }
    const editpass = (id) => {
        console.log('editing password with id' + id);
        setform(passwordarray.filter(i=>i.id===id)[0])
        setpasswordarray((passwordarray.filter(item=>item.id!==id)))
        
    }
    const handlechange = (e) => {
        setform({ ...form, [e.target.name]: e.target.value })


    }
    return (
        <>
            <ToastContainer
                position="top-right"
                autoClose={5000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick={false}
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="light"
                transition="Bounce" />
            <div className="absolute inset-0 -z-10 h-full w-full bg-white bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:14px_24px]"><div className="absolute left-0 right-0 top-0 -z-10 m-auto h-[310px] w-[310px] rounded-full bg-fuchsia-400 opacity-20 blur-[100px]"></div></div>
            <div className=" md: mx-auto  max-w-4xl">
                <div className="logo font-bold pl-20 text-4xl text-center pt-10 ">&lt;Pass  <span className="text-green-700">
                    OP / &gt;</span></div>
                <p className="2xl text-black text-center  ml-5 pl-9">Your Own Password Manager </p>

                <div className='text-black flex flex-col p-4 gap-8'>
                    <input value={form.site} onChange={handlechange} className="border-green-500  border-2 rounded-full p-2 py-1 " placeholder="Enter Website URL" type="text" name='site' id=' sitee' />
                    <div className="flex flex-col rounded-full gap-8 w-full sm:flex-row">
                        <input value={form.username} onChange={handlechange} className="rounded-full w-full border-green-500 border-2 gap-8 p-2 py-1 " placeholder="Enter Username" type="text" name="username" id="usernamee" />
                        <div className="relative">

                            <div className="">
                                <input ref={password} value={form.password} onChange={handlechange} className="rounded-full w-full border-green-500 border-2 gap-8 p-2 py-1 " placeholder="Enter Password " type="password" name="password" id="passwordd" />
                                </div>
                            <span className="absolute right-[3px] top-[4px] cursor-pointer" onClick={showpass}>
                                <img className="p-1 " ref={re} width={26} src="/images.png" alt="" />
                            </span>
                        </div>
                    </div>




                    <button onClick={savepass} className="mx-auto flex justify-center items-center bg-green-600 rounded-full px-8 py-2 w-fit hover:bg-green-400 border-2 border-green-900">
                        <lord-icon
                            src="https://cdn.lordicon.com/jgnvfzqg.json"
                            trigger="hover"
                        >
                        </lord-icon>
                        Save  </button>


                </div>
                <div className="password">
                    <h2 className="font-bold text-2xl py-4">Your Passwords </h2>
                    {passwordarray.length === 0 && <div className="text-black"> No Passwords To Show</div>}
                    {passwordarray.length != 0 &&
                        <table className="table-auto w-full rounded-xl overflow-hidden py-2 ">
                            <thead className=" bg-green-800 text-white">
                                <tr>
                                    <th>Site</th>
                                    <th>Username</th>
                                    <th>Password</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody className="bg-green-200">
                                {passwordarray.map((item, index) => {
                                    return <tr key={index}>

                                        <td className="-center " >
                                            <div className="flex items-center justify-center text">
                                                <a href={item.site} target='_blank'  >

                                                    <span>

                                                        {item.site}
                                                    </span>
                                                </a>
                                                <div className="size-7 cursor-pointer" onClick={() => { copyText(item.site) }}>
                                                    <lord-icon
                                                        src="https://cdn.lordicon.com/iykgtsbt.json"
                                                        trigger="hover"
                                                        style={{ "width": "25px", " height": "25px", "paddingTop": "3px", "paddingLeft": "3px" }}

                                                    >
                                                    </lord-icon>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="text-center ">
                                            <div className="flex items-center justify-center text">
                                                <span>
                                                    {item.username}
                                                </span>

                                                <div className="size-7 cursor-pointer" onClick={() => { copyText(item.username) }}>
                                                    <lord-icon
                                                        src="https://cdn.lordicon.com/iykgtsbt.json"
                                                        trigger="hover"
                                                        style={{ "width": "25px", " height": "25px", "paddingTop": "3px", "paddingLeft": "3px" }}

                                                    >
                                                    </lord-icon>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="text-center ">
                                            <div className="flex items-center justify-center text">
                                                <span>
                                                    {item.password}
                                                </span>

                                                <div className="size-7 cursor-pointer" onClick={() => { copyText(item.password) }}>
                                                    <lord-icon
                                                        src="https://cdn.lordicon.com/iykgtsbt.json"
                                                        trigger="hover"
                                                        style={{ "width": "25px", " height": "25px", "paddingTop": "3px", "paddingLeft": "3px" }}

                                                    >
                                                    </lord-icon>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="text-center ">
                                            <span onClick ={ ()=>{editpass(item.id)}}className="cursor-pointer mx-2">
                                                <lord-icon
                                                src="https://cdn.lordicon.com/gwlusjdu.json"
                                                trigger="hover"
                                                style={{ "width": "25px", "height": "25px" }}>
                                            </lord-icon></span>
                                            <span onClick ={ ()=>{ deletepass(item.id)}}className="cursor-pointer mx-2">
                                                <lord-icon
                                                src="https://cdn.lordicon.com/skkahier.json"

                                                trigger="hover"
                                                style={{ "width": "25px", "height": "25px" }}>
                                            </lord-icon></span>
                                        </td>
                                    </tr>
                                })}
                            </tbody>
                        </table>
                    }

                </div>
            </div>
        </>
    )
}

export default MAnager
