
export default function Footer() {
    return (
        <><div className="sticky mt-[23px]  bg-slate-800 flex flex-col justify-center items-center md:mt-[5px]">
            <div className=" mr-[70px] logo font-bold pl-20 text-2xl text-white"><span className="text-white p-1 hover:text-green-700">
                &lt;Pass
            </span>
                <span className="text-green-700">
                    OP / &gt;</span></div>
            <div className="font-bold text-white">
                Created By Devansh
            </div>
        </div>
           </>
    )
}
