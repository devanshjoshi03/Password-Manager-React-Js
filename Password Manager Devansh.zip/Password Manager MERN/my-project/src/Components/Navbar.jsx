// import { useState } from "react";
const Navbar = () => {
    // const [isOpen, setIsOpen] = useState(false);

    return (
        <>
            <nav className=' bg-slate-800 text-white     '>

                {/* <button
                    className="md:hidden"
                    onClick={() => setIsOpen(!isOpen)}
                >
                    ☰
                </button> */}
                <div className=" md: text-white hover:text-green-700 flex justify-between items-center py-5 px-4 h-14 " >
                    <div className="logo font-bold pl-20 text-2xl">
                        <div className="flex absolute left-0 top-3 md:ml-[300px]">
                            &lt;Pass  <span className="text-green-700">
                                OP /
                                &gt;
                            </span></div>
                    </div>
                    <ul className="">
                        <li className=' hidden lg:flex gap-4 text-white '>
                            <a className="hover:font-bold hover:text-black" href="/">Home</a>
                            <a className='hover:font-bold hover:text-black' href="">About</a>
                            <a className='hover:font-bold hover:text-black' href="">Contact</a>
                        </li>

                    </ul>
                    {/* {isOpen && (
                        <ul className="md:hidden mt-4 bg-blue-700 p-4 space-y-2">
                            <li><a href="#" className="block hover:underline">Home</a></li>
                            <li><a href="#" className="block hover:underline">About</a></li>
                            <li><a href="#" className="block hover:underline">Services</a></li>
                            <li><a href="#" className="block hover:underline">Contact</a></li>
                        </ul>
                    )} */}
                    <div className="ring-white ring-1 bg-green-700 rounded-md h-10 mx-5 flex hover:bg-white items-center justify-between hover:text-red-900  ">
                        <img className=" invert-1 p-4 w-14 cursor-pointer " src="/public/github.svg" alt="" />
                        <span className=" text-bold color-white ">GitHub</span>

                    </div>
                </div>
            </nav>
        </>
    )
}

export default Navbar
